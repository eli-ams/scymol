@echo off
rem Copyright (C) 2007-2015 Intel Corporation.  All Rights Reserved.
rem 
rem The source code contained or described herein and all documents
rem related to the source code ("Material") are owned by Intel Corporation
rem or its suppliers or licensors.  Title to the Material remains with
rem Intel Corporation or its suppliers and licensors.  The Material is
rem protected by worldwide copyright and trade secret laws and treaty
rem provisions.  No part of the Material may be used, copied, reproduced,
rem modified, published, uploaded, posted, transmitted, distributed, or
rem disclosed in any way without Intel's prior express written permission.
rem 
rem No license under any patent, copyright, trade secret or other
rem intellectual property right is granted to or conferred upon you by
rem disclosure or delivery of the Materials, either expressly, by
rem implication, inducement, estoppel or otherwise.  Any license under
rem such intellectual property rights must be express and approved by
rem Intel in writing.

"%I_MPI_ROOT%\intel64\bin\tune\mpitune.exe" %*
