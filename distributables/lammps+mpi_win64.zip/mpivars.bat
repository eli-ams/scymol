@echo off
Rem Intel(R) MPI Library Build Environment

if "%1" == "quiet" (
    shift
    goto EXPORTS
) else if "%2" == "quiet" (
    goto EXPORTS
)

title Intel(R) MPI Library 5.0 Runtime Environment Update 3 Build Environment for Intel(R) 64 applications

echo.
echo Intel(R) MPI Library 5.0 Runtime Environment Update 3 Build Environment for Intel(R) 64 applications
echo Copyright (C) 2007-2015 Intel Corporation. All rights reserved.
echo.

:EXPORTS
SET I_MPI_ROOT=%~dp0..\..
SET PATH=%I_MPI_ROOT%\intel64\bin;%PATH%
SET LIB=%I_MPI_ROOT%\intel64\lib;%LIB%
SET INCLUDE=%I_MPI_ROOT%\intel64\include;%INCLUDE%

if /i "%1"=="debug" (
    goto EXTRA_EXPORTS
)
if /i "%1"=="release" (
    goto EXTRA_EXPORTS
)
if /i "%1"=="debug_mt" (
    goto EXTRA_EXPORTS
)
if /i "%1"=="release_mt" (
    goto EXTRA_EXPORTS
)
goto END
                       
:EXTRA_EXPORTS
set PATH=%I_MPI_ROOT%\intel64\bin\%1;%PATH%

:END
